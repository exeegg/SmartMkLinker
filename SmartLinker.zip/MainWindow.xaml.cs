using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;
using Microsoft.Win32;

// 解决 CS0104 引用冲突
using ShapePath = System.Windows.Shapes.Path;
using WpfUiControls = Wpf.Ui.Controls;
using WpfControls = System.Windows.Controls;

namespace SmartLinker
{
    public partial class MainWindow : WpfUiControls.FluentWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            if (sender is WpfUiControls.Button btn)
            {
                var dialog = new OpenFolderDialog { Title = "选择物理存储或映射目标文件夹" };
                if (dialog.ShowDialog() == true)
                {
                    string path = dialog.FolderName;
                    string tag = btn.Tag?.ToString();
                    if (tag == "S1") Src1.Text = path;
                    else if (tag == "T1") Target1.Text = path;
                    else if (tag == "S2") Src2.Text = path;
                    else if (tag == "T2") Target2.Text = path;
                    else if (tag == "S3") Src3.Text = path;
                    else if (tag == "T3") Target3.Text = path;
                }
            }
        }

        private async Task<bool> ShowModernConfirmDialog(string title, string content)
        {
            var container = new WpfControls.StackPanel();
            var icon = new WpfUiControls.SymbolIcon { Symbol = WpfUiControls.SymbolRegular.Lightbulb24, FontSize = 64, Margin = new Thickness(0, 0, 0, 15), Foreground = new SolidColorBrush(Color.FromRgb(255, 193, 7)) };
            var text = new WpfControls.TextBlock { Text = content, TextWrapping = TextWrapping.Wrap, HorizontalAlignment = HorizontalAlignment.Center, TextAlignment = TextAlignment.Center };
            container.Children.Add(icon); container.Children.Add(text);
            var messageBox = new WpfUiControls.MessageBox { Title = title, Content = container, PrimaryButtonText = "确认重命名", CloseButtonText = "取消执行", MinWidth = 450 };
            return await messageBox.ShowDialogAsync() == WpfUiControls.MessageBoxResult.Primary;
        }

        private UIElement GetSuccessStarIcon()
        {
            var starIcon = new WpfUiControls.SymbolIcon { Symbol = WpfUiControls.SymbolRegular.Star24, FontSize = 72, Margin = new Thickness(0, 0, 0, 15) };
            LinearGradientBrush goldBrush = new LinearGradientBrush();
            goldBrush.GradientStops.Add(new GradientStop(Color.FromRgb(255, 223, 0), 0.0));
            goldBrush.GradientStops.Add(new GradientStop(Color.FromRgb(255, 160, 0), 1.0));
            starIcon.Foreground = goldBrush;
            starIcon.Effect = new DropShadowEffect { Color = Color.FromRgb(255, 215, 0), BlurRadius = 20, ShadowDepth = 0, Opacity = 0.6 };
            return starIcon;
        }

        private async void Execute_Click(object sender, RoutedEventArgs e)
        {
            var tasks = new List<(WpfUiControls.TextBox src, WpfUiControls.TextBox target)>();
            if (!string.IsNullOrWhiteSpace(Src1.Text) && !string.IsNullOrWhiteSpace(Target1.Text)) tasks.Add((Src1, Target1));
            if (!string.IsNullOrWhiteSpace(Src2.Text) && !string.IsNullOrWhiteSpace(Target2.Text)) tasks.Add((Src2, Target2));
            if (!string.IsNullOrWhiteSpace(Src3.Text) && !string.IsNullOrWhiteSpace(Target3.Text)) tasks.Add((Src3, Target3));

            if (tasks.Count == 0) return;
            string mode = RadioJunction.IsChecked == true ? "/J" : "/D";
            string reportLog = "";

            foreach (var item in tasks)
            {
                string sPath = item.src.Text.Trim(); string tPath = item.target.Text.Trim();
                if (Directory.Exists(tPath))
                {
                    if (await ShowModernConfirmDialog("冲突处理提示", $"映射路径已存在：\n{tPath}\n\n是否自动重命名为 '_old' 并继续？"))
                    {
                        string old = tPath.TrimEnd('\\', '/') + "_old";
                        if (Directory.Exists(old)) Directory.Delete(old, true);
                        Directory.Move(tPath, old);
                    } else continue;
                }
                try {
                    ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", $"/c mklink {mode} \"{tPath}\" \"{sPath}\"") { CreateNoWindow = true, UseShellExecute = false };
                    using (var p = Process.Start(psi)) { await p.WaitForExitAsync();
                        reportLog += p.ExitCode == 0 ? $" ✨ 成功: {System.IO.Path.GetFileName(tPath)}\n" : $" ❌ 失败: {System.IO.Path.GetFileName(tPath)}\n";
                    }
                } catch (Exception ex) { reportLog += $" ❌ 错误: {ex.Message}\n"; }
            }

            var resC = new WpfControls.StackPanel();
            resC.Children.Add(GetSuccessStarIcon());
            resC.Children.Add(new WpfControls.TextBlock { Text = "处理清单摘要：\n\n" + reportLog, HorizontalAlignment = HorizontalAlignment.Center });
            await new WpfUiControls.MessageBox { Title = "执行完成 - 软件蛋", Content = resC, CloseButtonText = "确认" }.ShowDialogAsync();
        }

        private void AuthorLink_Click(object sender, RoutedEventArgs e)
        {
            try { Process.Start(new ProcessStartInfo("https://exeegg.com") { UseShellExecute = true }); } catch { }
        }
    }
}